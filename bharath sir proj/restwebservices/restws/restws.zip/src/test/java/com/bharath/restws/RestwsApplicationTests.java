package com.bharath.restws;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RestwsApplicationTests {

	

}
